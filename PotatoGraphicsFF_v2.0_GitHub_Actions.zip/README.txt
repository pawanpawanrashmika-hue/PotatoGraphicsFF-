POTATO GRAPHICS FF v2.0 - Android Studio project

This is an offline companion guide for Free Fire players. It includes
English/Sinhala interface text, RAM presets (2GB/3GB/4GB), safe graphics
guidance, starter sensitivity values, a device checklist, and a 5-minute test.

It does NOT modify Free Fire, apply pixel textures, unlock FPS, access game
files, contain cheats, or guarantee performance improvements.

BUILD APK:
1. Install Android Studio (JDK 17) on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync; install Android SDK Platform 35 if requested.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

Requirements: Android Studio, JDK 17, Android SDK 35, internet for first Gradle sync.
Minimum Android version: Android 6.0 (API 23).
No INTERNET permission is requested by the app; app content works offline.

Independent fan-made guide. Not affiliated with Garena.
